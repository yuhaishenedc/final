import * as namespace from './namespace-re-export.js';
export { namespace };
