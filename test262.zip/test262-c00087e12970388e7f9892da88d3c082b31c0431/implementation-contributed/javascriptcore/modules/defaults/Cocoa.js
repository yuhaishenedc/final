export default class Cocoa {
    constructor() {
        this.taste = 'awesome';
    }
}
