
export const Cocoa = "Cocoa";

export let Cappuccino = "Cappuccino";

export default function changeCappuccino(value) {
    Cappuccino = value;
}

export * from "./additional-drink.js"
