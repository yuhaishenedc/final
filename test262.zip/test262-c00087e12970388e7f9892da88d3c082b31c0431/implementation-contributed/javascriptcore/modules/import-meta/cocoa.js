let meta = import.meta;
export {
    meta as cocoa
}
