let Cocoa = "Cocoa", Cappuccino = "Cappuccino", Matcha = "Matcha";

export let Modifier = {
    change(value)
    {
        Cocoa = value;
        Cappuccino = value;
        Matcha = value;
    }
};

export {
    Cocoa,
    Cappuccino,
    Matcha
};
