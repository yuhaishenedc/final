import { shouldBe } from "./resources/assert.js";

shouldBe(this, undefined);
