//       (A) *--> [B]
//            |    ^
//            |    |
//            +-> (C) *-> (D)
//                 ^
//                 |
//                (E)
//                 ^
//                 |
//                 @

import "uncacheable-when-see-star/main1.js"
import "uncacheable-when-see-star/main2.js"
