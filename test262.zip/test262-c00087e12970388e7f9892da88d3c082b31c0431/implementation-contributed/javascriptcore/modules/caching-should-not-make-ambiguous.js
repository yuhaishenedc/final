//                +----> (D) ------+
//                |                |
//                |                v
//   @-> (A) *----+----> (B) ---> [C]
import { A } from "caching-should-not-make-ambiguous/main.js"
