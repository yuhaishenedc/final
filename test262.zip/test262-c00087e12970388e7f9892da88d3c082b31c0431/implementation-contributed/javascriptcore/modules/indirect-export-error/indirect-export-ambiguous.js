export { A, B } from "./indirect-export-ambiguous-2.js"
