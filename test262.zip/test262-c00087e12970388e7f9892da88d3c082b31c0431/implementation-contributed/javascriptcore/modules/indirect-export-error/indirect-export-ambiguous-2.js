export * from "./indirect-export-ambiguous-3.js"
export * from "./indirect-export-ambiguous-4.js"
