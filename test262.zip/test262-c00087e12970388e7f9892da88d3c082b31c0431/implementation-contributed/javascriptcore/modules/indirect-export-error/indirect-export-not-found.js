export { A, B } from "./indirect-export-not-found-2.js";
