import "./1.js"

let value = 42;

export function add(a, b)
{
    return a + b;
}

export function raise()
{
    return value;
}
