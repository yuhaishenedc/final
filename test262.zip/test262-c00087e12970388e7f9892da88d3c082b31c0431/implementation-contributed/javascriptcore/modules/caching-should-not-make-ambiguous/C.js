export let A = 42;
