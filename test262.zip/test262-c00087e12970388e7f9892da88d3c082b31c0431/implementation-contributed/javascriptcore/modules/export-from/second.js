export let First = "Cocoa";

export var Second = "Cappuccino"

export default "Matcha";

var Mocha = 'Mocha';

export { Mocha as enum };
