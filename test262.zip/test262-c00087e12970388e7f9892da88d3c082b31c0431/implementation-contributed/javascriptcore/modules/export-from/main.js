export {
    First as Cocoa,
    Second as Cappuccino,
    default as enum,
    enum as default
} from "./second.js"
