export default function Cocoa() {
}
