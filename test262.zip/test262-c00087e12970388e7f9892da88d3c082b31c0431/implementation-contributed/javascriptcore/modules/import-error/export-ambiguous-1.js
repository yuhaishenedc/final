export const B = 42;
