export * from "./export-default-from-star-2.js"
