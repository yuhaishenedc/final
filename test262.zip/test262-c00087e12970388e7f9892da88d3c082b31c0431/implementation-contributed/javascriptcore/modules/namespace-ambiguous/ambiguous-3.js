export const Cocoa = 42;
