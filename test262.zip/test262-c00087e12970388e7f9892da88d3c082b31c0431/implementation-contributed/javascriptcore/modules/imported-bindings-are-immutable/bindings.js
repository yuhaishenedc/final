export var variable = 'Cocoa';

export const constVariable = 'Cocoa';

export let letVariable = 'Cocoa';

export function functionDeclaration() {
}

export class classDeclaration {
}
