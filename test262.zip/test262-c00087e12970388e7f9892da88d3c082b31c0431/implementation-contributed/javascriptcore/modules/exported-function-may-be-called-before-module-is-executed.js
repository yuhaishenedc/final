import "./exported-function-may-be-called-before-module-is-executed/2.js"
