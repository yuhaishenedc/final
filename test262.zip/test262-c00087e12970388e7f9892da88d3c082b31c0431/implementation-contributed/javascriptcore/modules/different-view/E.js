export let A = 50;
